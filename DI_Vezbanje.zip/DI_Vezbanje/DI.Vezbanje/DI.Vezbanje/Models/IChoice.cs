﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Vezbanje.Models
{
    public interface IChoice
    {
        public enum Choice
        {
            Rock,
            Paper,
            Scissors
        }
    }
}
